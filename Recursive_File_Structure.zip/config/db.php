<?php

    $db = [                
        'dbhost' => 'localhost',
        'dbuser' => 'root',
        'dbpass' => '',
        'dbname' => 'flstrcture'
    ];

